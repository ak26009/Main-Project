#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "N-link";        // Replace with your Wi-Fi SSID
const char* password = "7385607385"; // Replace with your Wi-Fi password

WebServer server(80);  // Create a web server on port 80

// Define GPIO pins for each device
const int fanPin = 14;
const int lightPin = 15;
const int heaterPin = 16;
const int UvPin = 17;
const int m1 = 23;
const int m2 = 22;



// Variables to keep track of device states
bool fanState = false;
bool lightState = false;
bool heaterState = false;
bool UvState = false;
bool motorForward = false;
bool motorbackward =  false;


void setup() {
  Serial.begin(115200);

  // Set up GPIO pins as outputs
  pinMode(fanPin, OUTPUT);
  pinMode(lightPin, OUTPUT);
  pinMode(heaterPin, OUTPUT);
  pinMode(UvPin, OUTPUT);
  pinMode( m1, OUTPUT);
  pinMode(m2,OUTPUT);
  // Set initial states to LOW (OFF)
  digitalWrite(fanPin, LOW);
  digitalWrite(lightPin, LOW);
  digitalWrite(heaterPin, LOW);
  digitalWrite(UvPin, LOW);
  digitalWrite(m1, LOW);
  digitalWrite(m2, LOW);


  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected to WiFi");

  // Print the IP address
  Serial.print("ESP32-CAM IP Address: ");
  Serial.println(WiFi.localIP());

  // Set up URL routes and their handlers
  server.on("/", handleRoot);  // Root URL
  server.on("/toggleFan", handleFanToggle);     // URL to toggle fan
  server.on("/toggleLight", handleLightToggle); // URL to toggle light
  server.on("/toggleHeater", handleHeaterToggle); // URL to toggle heater
  server.on("/toggleUv", handleUvToggle);
  server.on("/toggleM1",handleMforward);
  server.on("/toggleM2",handleMbackward);

  // Start the server
  server.begin();
  Serial.println("HTTP server started");
}

void loop() {
  server.handleClient(); // Handle incoming client requests
}

// Root handler (optional welcome message)
void handleRoot() {
  server.send(200, "text/plain", "ESP32 Home Automation Server");
}

// Function to toggle the fan state and update GPIO
// void handleFanToggle() {
//   fanState = !fanState;
//   Serial.println(fanState);
//   digitalWrite(fanPin, fanState ? HIGH : LOW);  // Set GPIO pin based on state
//   String message = fanState ? "Fan is ON" : "Fan is OFF";
//   server.send(200, "text/plain", message);
//   Serial.println(message);
   
// }

// // Function to toggle the light state and update GPIO
// void handleLightToggle() {
//   lightState = !lightState;
//   digitalWrite(lightPin, lightState ? HIGH : LOW);  // Set GPIO pin based on state
//   String message = lightState ? "Light is ON" : "Light is OFF";
//   server.send(200, "text/plain", message);
//   Serial.println(message);
// }

// // Function to toggle the heater state and update GPIO
// void handleHeaterToggle() {
//   heaterState = !heaterState;
//   digitalWrite(heaterPin, heaterState ? HIGH : LOW);  // Set GPIO pin based on state
//   String message = heaterState ? "Heater is ON" : "Heater is OFF";
//   server.send(200, "text/plain", message);
//   Serial.println(message);
// }
void handleFanToggle() {
  fanState = !fanState;  // Toggle the fan state
  digitalWrite(fanPin, fanState ? HIGH : LOW);
  
  // Send the new state as a response
  String message = fanState ? "OFF" : "ON"; 
  server.send(200, "text/plain", message);
  
  Serial.println(fanState ? "Fan is OFF" : "Fan is ON");
}

void handleLightToggle() {
  lightState = !lightState;
  digitalWrite(lightPin, lightState ? HIGH : LOW);
  String message = lightState ? "OFF" : "ON";
  server.send(200, "text/plain",message); // Send "ON" or "OFF" state
  
}

void handleHeaterToggle() {
  heaterState = !heaterState;
  digitalWrite(heaterPin, heaterState ? HIGH : LOW);
  String message = heaterState ? "OFF" : "ON";
  server.send(200, "text/plain", message); // Send "ON" or "OFF" state
  Serial.println(message);
}
void handleUvToggle() {
  UvState = !UvState;
  digitalWrite(UvPin, UvState ? HIGH : LOW);
  String message = UvState ? "OFF" : "ON";
  server.send(200, "text/plain", message); // Send "ON" or "OFF" state
  Serial.println(message);
}
void handleMforward() {
  motorForward = !motorForward;
  digitalWrite(m1, motorForward ? HIGH : LOW);
  String message = motorForward ? "OFF" : "ON";
  server.send(200, "text/plain", message); // Send "ON" or "OFF" state
  Serial.println(message);
}
void handleMbackward() {
  motorbackward = !motorbackward;
  digitalWrite(m2, motorbackward ? HIGH : LOW);
  String message = motorbackward ? "OFF" : "ON";
  server.send(200, "text/plain", message); // Send "ON" or "OFF" state
  Serial.println(message);
}


